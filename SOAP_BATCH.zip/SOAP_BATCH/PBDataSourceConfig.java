package com.goomo.loyalty.config;

import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.transport.http.HttpComponentsMessageSender;

import com.goomo.loyalty.clients.PBMyAccountWSClient;
import com.goomo.loyalty.clients.PBTransactionWSClient;
import com.goomo.loyalty.constant.APPConstants;
import com.goomo.loyalty.domain.PBDataSource;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * This class used to create data source object for payback related properties.
 * 
 * @author Manjunath Jakkandi
 *
 */
@Configuration
@Slf4j
public class PBDataSourceConfig {

	//private static final Logger log = LoggerFactory.getLogger(PBDataSourceConfig.class);

	@Value("${spring.profiles.active}")
	private String domain;
	
	@Value("${payback.base.url}")
	private String baseURL;

	@Value("${payback.terminal.id}")
	private String terminalId;

	@Value("${payback.merchant.id}")
	private String merchantId;

	@Value("${payback.classification.code}")
	private String classificationCode;

	@Value("${payback.txn.channel}")
	private String txnChannel;

	@Value("${payback.lm.id}")
	private String lmId;

	@Value("${payback.lt.id}")
	private String ltId;

	@Value("${payback.partner.short.name}")
	private String partnerShortName;

	@Value("${payback.communication.channel}")
	private int communicationChannel;

	@Value("${payback.promotional.id}")
	private int promotionalId;

	@Value("${payback.source.association.id}")
	private int sourceAssociationId;

	@Value("${payback.physical.cardtype.id}")
	private int physicalCardTypeId;

	@Value("${payback.memer.cardtype.id}")
	private int memberCardTypeId;

	@Value("${payback.member.class.id}")
	private int memberClassId;

	@Value("${payback.privatekey}")
	private String privateKey;

	@Value("${payback.partner.authkey}")
	private String partnerAuthKey;

	@Value("${payback.blocking.period}")
	private String blockingPeriod;

	/**
	 * @author Manjunath Jakkandi This method used to initialise marshaller object
	 *         for payback api's.
	 * @return Jaxb2Marshaller
	 */
	@Bean
	public Jaxb2Marshaller marshaller() {
		Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
		marshaller.setContextPath("net.payback.lmsglobal.ws.v1.extint.types");
		return marshaller;
	}

	/**
	 * @author Manjunath Jakkandi This method used to initialise webservice template
	 *         for payback end point.
	 * @return WebServiceTemplate
	 */
	@Bean
	public WebServiceTemplate webServiceTemplate() throws Exception {
		WebServiceTemplate webServiceTemplate = new WebServiceTemplate();
		webServiceTemplate.setMarshaller(marshaller());
		webServiceTemplate.setUnmarshaller(marshaller());
		webServiceTemplate.setDefaultUri(getDataSource().getBaseURL());
		return webServiceTemplate;
	}

	/**
	 * @author Manjunath Jakkandi This method used to initialize payback client to
	 *         handle API's for my account related API's. Client is responsible for
	 *         creating payback request object and invoke.
	 * @return MyAccountWSClient
	 */
	@Bean
	public PBMyAccountWSClient payBackClient(HttpComponentsMessageSender httpComponentsMessageSender) throws Exception{
		Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
		marshaller.setContextPath("net.payback.lmsglobal.xsd.v1.types");
		PBMyAccountWSClient myAccountClient = new PBMyAccountWSClient();
		myAccountClient.setDefaultUri(getDataSource().getBaseURL());
		myAccountClient.setMarshaller(marshaller);
		myAccountClient.setUnmarshaller(marshaller);
		myAccountClient.setMessageSender(httpComponentsMessageSender);
		return myAccountClient;
	}

	/**
	 * @author Manjunath Jakkandi This method used to initialize payback client to
	 *         handle API's for transaction related API's. This client is
	 *         responsible for creating payback request object and invoke.
	 * @return TransactionWSClient
	 */
	@Bean
	public PBTransactionWSClient txnWSClient(HttpComponentsMessageSender httpComponentsMessageSender) throws Exception {
		Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
		marshaller.setContextPath("net.payback.lmsglobal.xsd.v1.types");
		PBTransactionWSClient txnWSClient = new PBTransactionWSClient();
		txnWSClient.setDefaultUri(getDataSource().getBaseURL());
		txnWSClient.setMarshaller(marshaller);
		txnWSClient.setUnmarshaller(marshaller);
		txnWSClient.setMessageSender(httpComponentsMessageSender);
		return txnWSClient;
	}

	@Bean
	public HttpComponentsMessageSender httpComponentsMessageSender() {
		HttpComponentsMessageSender sender = new HttpComponentsMessageSender();
		sender.setReadTimeout(30000);
		sender.setConnectionTimeout(30000);
		return sender;
	}
	
	@Bean
	public synchronized PBDataSource getDataSource() throws Exception {
		// if domain type is dev -> read from property file. If domain type is prod, read from system property file.
		log.info("Domain :: "+ domain);
		PBDataSource dataSource = null;
		if (domain != null && !domain.isEmpty() && domain.equalsIgnoreCase("dev")) {
			dataSource = getDevelopmentDataSource();
		} else {
			dataSource = getProductionDataSource();
		}
		return dataSource;
	}

	private PBDataSource getDevelopmentDataSource() throws Exception {
		PBDataSource dataSource = new PBDataSource();
		dataSource.setBaseURL(baseURL);
		dataSource.setTerminalId(terminalId);
		dataSource.setMerchantId(merchantId);
		// dataSource.setClassificationCode(classificationCode);
		dataSource.setTxnChannel(txnChannel);
		dataSource.setLmId(lmId);
		dataSource.setLtId(ltId);
		dataSource.setPartnerShortName(partnerShortName);
		dataSource.setCommunicationChannel(communicationChannel);
		dataSource.setPromotionalId(promotionalId);
		dataSource.setSourceAssociationId(sourceAssociationId);
		dataSource.setPhysicalCardTypeId(physicalCardTypeId);
		dataSource.setMemberCardTypeId(memberCardTypeId);
		dataSource.setMemberClassId(memberClassId);
		dataSource.setPrivateKey(privateKey);
		dataSource.setPartnerAuthKey(partnerAuthKey);
		dataSource.setBlockingPeriod(blockingPeriod);
		return dataSource;
	}

	private PBDataSource getProductionDataSource() throws Exception {
		PBDataSource dataSource = new PBDataSource();
		Map<String, String> env = System.getenv();
		dataSource.setBaseURL(env.get(APPConstants.BASE_URL));
		dataSource.setTerminalId(env.get(APPConstants.TERMINAL_ID));
		dataSource.setMerchantId(env.get(APPConstants.MERCHANT_ID));
		// dataSource.setClassificationCode(env.get(APPConstants.CLASSIFICATION_CODE));
		dataSource.setTxnChannel(env.get(APPConstants.TXN_CHANNEL));
		dataSource.setLmId(env.get(APPConstants.LM_ID));
		dataSource.setLtId(env.get(APPConstants.LT_ID));
		dataSource.setPartnerShortName(env.get(APPConstants.PARTNER_SHORT_NAME));
		if(env.get(APPConstants.COMMUNICATION_CHANNEL)!=null) {
			dataSource.setCommunicationChannel(Integer.valueOf(env.get(APPConstants.COMMUNICATION_CHANNEL)));
		}
		if(env.get(APPConstants.PROMOTIONAL_ID)!=null) {
			dataSource.setPromotionalId(Integer.valueOf(env.get(APPConstants.PROMOTIONAL_ID)));
		}
		if(env.get(APPConstants.SOURCE_ASSOCIATION_ID)!=null) {
			dataSource.setSourceAssociationId(Integer.valueOf(env.get(APPConstants.SOURCE_ASSOCIATION_ID)));
		}
		if(env.get(APPConstants.SOURCE_ASSOCIATION_ID)!=null) {
			dataSource.setPhysicalCardTypeId(Integer.valueOf(env.get(APPConstants.PHYSICAL_CARD_TYPE_ID)));
		}
		if(env.get(APPConstants.MEMBER_CARD_TYPE_ID)!=null) {
			dataSource.setMemberCardTypeId(Integer.valueOf(env.get(APPConstants.MEMBER_CARD_TYPE_ID)));
		}
		if(env.get(APPConstants.MEMBER_CLASS_ID)!=null) {
			dataSource.setMemberClassId(Integer.valueOf(env.get(APPConstants.MEMBER_CLASS_ID)));
		}
		dataSource.setPrivateKey(env.get(APPConstants.PRIVATE_KEY));
		dataSource.setPartnerAuthKey(env.get(APPConstants.PARTNER_AUTH_KEY));
		dataSource.setBlockingPeriod(env.get(APPConstants.POINTS_BLOCK_PERIOD));
		return dataSource;
	}

}