package com.goomo.loyalty.clients;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;

import com.goomo.loyalty.auth.PBEWithMD5andDES;
import com.goomo.loyalty.config.PBDataSourceConfig;
import com.goomo.loyalty.constant.APPConstants;
import com.goomo.loyalty.helper.PBValidateMyAccount;

import lombok.extern.slf4j.Slf4j;
import net.payback.lmsglobal.ws.v1.extint.types.BlockPointsForRedemptionRequest;
import net.payback.lmsglobal.ws.v1.extint.types.BlockPointsForRedemptionResponse;
import net.payback.lmsglobal.ws.v1.extint.types.CreateEarnTransactionRequest;
import net.payback.lmsglobal.ws.v1.extint.types.CreateEarnTransactionResponse;
import net.payback.lmsglobal.ws.v1.extint.types.ReverseEarnTransactionRequest;
import net.payback.lmsglobal.ws.v1.extint.types.ReverseEarnTransactionRequest.OldTxnId;
import net.payback.lmsglobal.ws.v1.extint.types.ReverseEarnTransactionResponse;
import net.payback.lmsglobal.ws.v1.extint.types.ReverseVoucherRedemptionRequest;
import net.payback.lmsglobal.ws.v1.extint.types.ReverseVoucherRedemptionResponse;
import net.payback.lmsglobal.xsd.v1.types.AssociationsType;
import net.payback.lmsglobal.xsd.v1.types.AuthenticationType;
import net.payback.lmsglobal.xsd.v1.types.MemberAuthenticationType;
import net.payback.lmsglobal.xsd.v1.types.PrincipalType;
import net.payback.lmsglobal.xsd.v1.types.StatusType;

/**
 * This class used to consume payback soap API's for transactions. Such as
 * create earn, reverse earn, block redemption and reverse redemption voucher.
 * 
 * @author Manjunath Jakkandi
 *
 */
@Slf4j
public class PBTransactionWSClient extends WebServiceGatewaySupport {

	//private static final Logger log = LoggerFactory.getLogger(PBTransactionWSClient.class);

	@Autowired
	PBDataSourceConfig config;

	/**
	 * This method used to consume payback API for create earn transaction.
	 * 
	 * @author Manjunath Jakkandi
	 * @param authenticationNumber
	 *            mobile number or card number
	 * @param partnerUID
	 *            Goomo product booking id
	 * @param txnAmount
	 *            total amount for which points to be created
	 * @param txnPoints
	 *            total number of points to be earned.
	 * @return CreateEarnTransactionResponse
	 */
	public CreateEarnTransactionResponse createEarnTransaction(String authenticationNumber, String partnerUID,
			String txnPoints, String blockEarnDate,String txnAmount, String classificationCode,String bookingId) throws Exception {

		CreateEarnTransactionResponse response = null;
		CreateEarnTransactionRequest request = new CreateEarnTransactionRequest();
		MemberAuthenticationType type = new MemberAuthenticationType();
		type.setAuthenticationNumber(authenticationNumber);
		if (PBValidateMyAccount.isPrinicipalMobileNumber(authenticationNumber)) {
			type.setAssociationType(AssociationsType.MOBILE_ID);
		}
		request.setMemberAuthentication(type);
		
		/**
		 * converting input block earn date to +1 day and setting the required format for payback.
		 */
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
		Date date = sdf1.parse(blockEarnDate);
		Date plusOneDate = new Date(date.getTime() + (1000 * 60 * 60 * 24));
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss", Locale.getDefault());
		String blockEarnDateStr = sdf.format(plusOneDate);
		String currentDateStr = sdf.format(new Date());
		PBEWithMD5andDES key = new PBEWithMD5andDES();

		/**
		 * Order of valueString to encrypt for create earn transaction
		 * AuthenticationNumber + ActualTxnValue + AdditionalInfoForDisplay + BranchId +
		 * CampaignId + TxnMerchantId + PartnerUId + TxnAmount + TxnBatchNo + TxnChannel
		 * + TxnClassificationCode + TxnDateTime + TxnPoints + TxnSettlementDate +
		 * TxnInvoiceNumber + TxnTerminalId + GetIsPrepaid
		 */
		String valueStringToEncrypt = null; 
		if (classificationCode.equalsIgnoreCase(APPConstants.ClassificationCode.BONUS_POINTS.name())) {
		      valueStringToEncrypt = authenticationNumber + bookingId + config.getDataSource().getMerchantId()
				+ partnerUID + config.getDataSource().getTxnChannel()
				+ classificationCode + currentDateStr + txnPoints + blockEarnDateStr
				+ bookingId + config.getDataSource().getTerminalId();
		      
		} else {
			  valueStringToEncrypt = authenticationNumber + bookingId + config.getDataSource().getMerchantId()
					+ partnerUID + txnAmount+config.getDataSource().getTxnChannel()
					+ classificationCode + currentDateStr + txnPoints + blockEarnDateStr
					+ bookingId + config.getDataSource().getTerminalId();
			  request.setTxnAmount(BigDecimal.valueOf(Long.valueOf(txnAmount)));
		}
		
		String PartnerAuthorizationKey = key.getPartnerAuthoriationKey(config.getDataSource().getLmId(),
				valueStringToEncrypt, config.getDataSource().getPrivateKey(),
				config.getDataSource().getPartnerAuthKey());
		request.setPartnerAuthorizationKey(PartnerAuthorizationKey);
		request.setTxnMerchantId(config.getDataSource().getMerchantId());
		request.setTxnTerminalId(config.getDataSource().getTerminalId());
		request.setTxnClassificationCode(classificationCode);
		request.setTxnChannel(config.getDataSource().getTxnChannel());
		request.setPartnerUId(partnerUID);
		request.setTxnInvoiceNumber(bookingId);
		request.setTxnPoints(BigDecimal.valueOf(Long.valueOf(txnPoints)));
		request.setAdditionalInfoForDisplay(bookingId);
		
		XMLGregorianCalendar txnDatexgcal = DatatypeFactory.newInstance().newXMLGregorianCalendar(currentDateStr);
		XMLGregorianCalendar txnSettlementxgcal = DatatypeFactory.newInstance().newXMLGregorianCalendar(blockEarnDateStr);
		request.setTxnDateTime(txnDatexgcal);
		request.setTxnSettlementDate(txnSettlementxgcal);
		
		response = (CreateEarnTransactionResponse) getWebServiceTemplate().marshalSendAndReceive(request);
		return response;
	}

	/**
	 * This method used to consume payback soap API for reverse earn transaction.
	 * 
	 * @author Manjunath Jakkandi
	 * @param authenticationNumber
	 *            mobile number or card number
	 * @param oldPartnerUId
	 *            previous or old goomo booking id
	 * @param newPartnerUId
	 *            updated or new goomo booking id
	 * @param txnAmount
	 *            total amount for which reverse earn transaction to be triggered
	 * @param txnPoints
	 *            total number of points for which reverse earn transaction to be
	 *            triggered.
	 * @return ReverseEarnTransactionResponse
	 */
	public ReverseEarnTransactionResponse reverseEarnTransaction(String authenticationNumber, String oldPartnerUId,
			String newPartnerUId, String txnPoints) throws Exception {

		ReverseEarnTransactionResponse response = null;
		ReverseEarnTransactionRequest request = new ReverseEarnTransactionRequest();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss", Locale.getDefault());
		String currentDateStr = sdf.format(new Date());

		MemberAuthenticationType type = new MemberAuthenticationType();
		type.setAuthenticationNumber(authenticationNumber);
		if (PBValidateMyAccount.isPrinicipalMobileNumber(authenticationNumber)) {
			type.setAssociationType(AssociationsType.MOBILE_ID);
		}
		request.setMemberAuthentication(type);
		request.setNewPartnerUId(newPartnerUId);
		request.setTxnChannel(config.getDataSource().getTxnChannel());
		request.setTxnMerchantId(config.getDataSource().getMerchantId());
		request.setTxnTerminalId(config.getDataSource().getTerminalId());
		XMLGregorianCalendar xgcal = DatatypeFactory.newInstance().newXMLGregorianCalendar(currentDateStr);
		request.setTxnDateTime(xgcal);
		request.setTxnPoints(BigDecimal.valueOf(Long.valueOf(txnPoints)));
		OldTxnId oldTxnId = new OldTxnId();
		oldTxnId.setOldPartnerUId(oldPartnerUId);
		request.setOldTxnId(oldTxnId);

		/**
		 * Order of valueString to encrypt for create earn transaction
		 * AuthenticationNumber + newPartnerUId + Txn_Channel + Txn_Merchant_Id +
		 * Txn_Terminal_Id + currentDateStr + txnPoints + oldPartnerUId
		 */
		String valueStringToEncrypt = authenticationNumber + newPartnerUId + config.getDataSource().getTxnChannel()
				+ config.getDataSource().getMerchantId() + config.getDataSource().getTerminalId()
				+ currentDateStr + txnPoints + oldPartnerUId;
		log.info("valueStringToEncrypt >>>> " + valueStringToEncrypt);
		PBEWithMD5andDES key = new PBEWithMD5andDES();
		String PartnerAuthorizationKey = key.getPartnerAuthoriationKey(config.getDataSource().getLmId(),
				valueStringToEncrypt, config.getDataSource().getPrivateKey(),
				config.getDataSource().getPartnerAuthKey());
		log.info("PartnerAuthorizationKey >>>> " + PartnerAuthorizationKey);
		request.setPartnerAuthorizationKey(PartnerAuthorizationKey);

		response = (ReverseEarnTransactionResponse) getWebServiceTemplate().marshalSendAndReceive(request);
		return response;
	}

	/**
	 * This method used to consume payback soap api for block redemption.
	 * 
	 * @author Manjunath Jakkandi
	 * @param principal
	 *            mobile number or card number
	 * @param credential
	 *            payback PIN number
	 * @param invoiceNum
	 *            goomo booking id
	 * @param pointsToBlock
	 *            total number of points to be blocked for redemption.
	 * @return
	 */
	public BlockPointsForRedemptionResponse blockRedemption(String principal, String credential, String invoiceNum,
			String pointsToBlock,String bookignId) throws Exception {
		BlockPointsForRedemptionResponse response = null;
		BlockPointsForRedemptionRequest request = new BlockPointsForRedemptionRequest();
		AuthenticationType type = new AuthenticationType();
		PrincipalType type1 = new PrincipalType();
		type1.setPrincipalValue(principal);
		type1.setPrincipalClassifier(PBValidateMyAccount.getAliasType(principal));
		type.setPrincipal(type1);
		type.setCredential(credential);
		request.setMemberAuthentication(type);
		request.setLmid(config.getDataSource().getLmId());
		request.setLtid(config.getDataSource().getLtId());
		request.setInvoiceNum(invoiceNum);
		//request.setReceiptCode(invoiceNum + "23");
		request.setReceiptCode(bookignId);
		request.setPointsToBlock(BigDecimal.valueOf(Long.valueOf(pointsToBlock)));
		request.setTxnChannel(config.getDataSource().getTxnChannel());
		request.setSendSMS(StatusType.YES);
		response = (BlockPointsForRedemptionResponse) getWebServiceTemplate().marshalSendAndReceive(request);
		return response;
	}

	/**
	 * This method used to consume payback soap api for reverse redemption.
	 * 
	 * @author Manjunath Jakkandi
	 * @param orderId
	 *            goomo booking id
	 * @param refundPoints
	 *            total number of points to be refunded or reverse the redemption.
	 * @return ReverseVoucherRedemptionResponse
	 */
	public ReverseVoucherRedemptionResponse reverseRedemption(String orderId, String refundPoints) throws Exception {
		ReverseVoucherRedemptionResponse response = null;
		ReverseVoucherRedemptionRequest request = new ReverseVoucherRedemptionRequest();
		request.setOrderId(orderId);
		request.setRedemptionChannel(config.getDataSource().getLmId());
		request.setRefundPoints(BigDecimal.valueOf(Long.valueOf(refundPoints)));
		response = (ReverseVoucherRedemptionResponse) getWebServiceTemplate().marshalSendAndReceive(request);
		return response;
	}

}
