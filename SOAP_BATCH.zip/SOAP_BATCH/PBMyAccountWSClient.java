package com.goomo.loyalty.clients;

import java.math.BigInteger;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;

import com.goomo.loyalty.config.PBDataSourceConfig;
import com.goomo.loyalty.helper.PBValidateMyAccount;
import com.goomo.loyalty.model.PBAccountBalanceRequestModel;
import com.goomo.loyalty.model.PBEnrollRequestModel;

import lombok.extern.slf4j.Slf4j;
import net.payback.lmsglobal.ws.v1.extint.types.AuthenticateRequest;
import net.payback.lmsglobal.ws.v1.extint.types.AuthenticateResponse;
import net.payback.lmsglobal.ws.v1.extint.types.EnrollMemberRequest;
import net.payback.lmsglobal.ws.v1.extint.types.EnrollMemberResponse;
import net.payback.lmsglobal.ws.v1.extint.types.ForgotPasswordRequest;
import net.payback.lmsglobal.ws.v1.extint.types.ForgotPasswordResponse;
import net.payback.lmsglobal.ws.v1.extint.types.GetAccountBalanceRequest;
import net.payback.lmsglobal.ws.v1.extint.types.GetAccountBalanceResponse;
import net.payback.lmsglobal.ws.v1.extint.types.GetMemberCardDetailsByMobileRequest;
import net.payback.lmsglobal.ws.v1.extint.types.GetMemberCardDetailsByMobileResponse;
import net.payback.lmsglobal.ws.v1.extint.types.GetMemberCardsByEmailIdRequest;
import net.payback.lmsglobal.ws.v1.extint.types.GetMemberCardsByEmailIdResponse;
import net.payback.lmsglobal.ws.v1.extint.types.IsMobileLinkedRequest;
import net.payback.lmsglobal.ws.v1.extint.types.IsMobileLinkedResponse;
import net.payback.lmsglobal.xsd.v1.types.AuthenticationType;
import net.payback.lmsglobal.xsd.v1.types.ConsumerAuthenticationType;
import net.payback.lmsglobal.xsd.v1.types.ConsumerIdentificationType;
import net.payback.lmsglobal.xsd.v1.types.EmailAddressType;
import net.payback.lmsglobal.xsd.v1.types.EnrollMemberContactType;
import net.payback.lmsglobal.xsd.v1.types.EnrolmentDetailsType;
import net.payback.lmsglobal.xsd.v1.types.MemberAliasAuthenticationType;
import net.payback.lmsglobal.xsd.v1.types.MemberIdentificationType;
import net.payback.lmsglobal.xsd.v1.types.MemberMasterInfoType;
import net.payback.lmsglobal.xsd.v1.types.MemberPostalAddressType;
import net.payback.lmsglobal.xsd.v1.types.MemberSecurityType;
import net.payback.lmsglobal.xsd.v1.types.PhoneNumberType;
import net.payback.lmsglobal.xsd.v1.types.PrincipalType;
import net.payback.lmsglobal.xsd.v1.types.StatusType;

/**
 * This class used as client to connect payback SOAP API's using web service
 * template. API's such as account balance, fotgot password, is mobile linked,
 * enroll request etc,.
 * 
 * @author Manjunath Jakkandi
 *
 */
@Slf4j
public class PBMyAccountWSClient extends WebServiceGatewaySupport {

	//private static final Logger log = LoggerFactory.getLogger(PBMyAccountWSClient.class);

	@Autowired
	PBDataSourceConfig config;

	/**
	 * This method used to consume get account balance for given principal.
	 * credential is optional parameter.
	 * 
	 * @author Manjunath Jakkandi
	 * @param principal
	 *            is mobile number or card number.
	 * @param credential
	 *            payback PIN number.
	 * @return GetAccountBalanceResponse
	 */
	public GetAccountBalanceResponse getAccountBalance(PBAccountBalanceRequestModel pbAccountBalanceRequestModel)
			throws Exception {
		log.info("GetAccountBalanceResponse");
		GetAccountBalanceResponse response = null;
		GetAccountBalanceRequest request = new GetAccountBalanceRequest();
		AuthenticationType type = new AuthenticationType();
		PrincipalType pt = new PrincipalType();
		pt.setPrincipalValue(pbAccountBalanceRequestModel.getPrincipal());
		pt.setPrincipalClassifier(PBValidateMyAccount.getAliasType(pbAccountBalanceRequestModel.getPrincipal()));
		type.setPrincipal(pt);
		if (pbAccountBalanceRequestModel.getCredential() != null
				&& !pbAccountBalanceRequestModel.getCredential().isEmpty()) {
			type.setCredential(pbAccountBalanceRequestModel.getCredential());
		}
		request.setAuthentication(type);
		response = (GetAccountBalanceResponse) getWebServiceTemplate().marshalSendAndReceive(request);
		return response;
	}

	/**
	 * This method used to consume payback authenticate API for a given principal.
	 * 
	 * @author Manjunath Jakkandi
	 * @param principal
	 *            is mobile number or card number.
	 * @return AuthenticateResponse
	 */
	public AuthenticateResponse authenticatePrinciapl(String principal) throws Exception {
		log.info("authenticatePrinciapl");
		AuthenticateResponse response = null;
		AuthenticateRequest request = new AuthenticateRequest();

		ConsumerIdentificationType type = new ConsumerIdentificationType();
		ConsumerAuthenticationType type1 = new ConsumerAuthenticationType();
		type1.setPrincipal(principal);
		type.setConsumerAuthentication(type1);
		request.setConsumerIdentification(type);

		MemberAliasAuthenticationType memAlias = new MemberAliasAuthenticationType();
		MemberIdentificationType memIdentificationType = new MemberIdentificationType();
		memIdentificationType.setAlias(principal);
		memIdentificationType.setAliasType(BigInteger.valueOf(PBValidateMyAccount.getAliasType(principal)));
		memAlias.setIdentification(memIdentificationType);
		request.setAuthentication(memAlias);

		request.setCommunicationChannel(config.getDataSource().getCommunicationChannel());
		response = (AuthenticateResponse) getWebServiceTemplate().marshalSendAndReceive(request);
		return response;
	}

	/**
	 * This method used to consume payback forgot password API for given mobile
	 * number or card number.
	 * 
	 * @author Manjunath Jakkandi
	 * @param alias
	 *            is mobile number or card number.
	 * @return ForgotPasswordResponse
	 */
	public ForgotPasswordResponse forgotPassword(String alias) throws Exception {
		log.info("forgotPassword");
		ForgotPasswordResponse response = null;
		ForgotPasswordRequest request = new ForgotPasswordRequest();
		MemberAliasAuthenticationType type = new MemberAliasAuthenticationType();

		MemberIdentificationType type1 = new MemberIdentificationType();
		type1.setAlias(alias);
		type1.setAliasType(BigInteger.valueOf(PBValidateMyAccount.getAliasType(alias)));
		type.setIdentification(type1);

		MemberSecurityType memSecurityType = new MemberSecurityType();
		memSecurityType.setSecretType(BigInteger.valueOf(0));
		type.setSecurity(memSecurityType);

		request.setAuthentication(type);
		request.setCommunicationChannel(config.getDataSource().getCommunicationChannel());
		request.setSendMobileAndEmail(StatusType.YES);

		response = (ForgotPasswordResponse) getWebServiceTemplate().marshalSendAndReceive(request);
		return response;
	}

	/**
	 * This method used to consume payback API to validate is mobile linked or not
	 * for given mobile number.
	 * 
	 * @author Manjunath Jakkandi
	 * @param mobileNumber
	 *            payback registered mobile number
	 * @return IsMobileLinkedResponse
	 */
	public IsMobileLinkedResponse isMobileLinked(String mobileNumber) throws Exception {
		log.info("isMobileLinked");
		IsMobileLinkedResponse response = null;
		IsMobileLinkedRequest request = new IsMobileLinkedRequest();
		request.setMobileNumber(mobileNumber);
		response = (IsMobileLinkedResponse) getWebServiceTemplate().marshalSendAndReceive(request);
		return response;
	}

	/**
	 * This method used to consume payback API for enroll request.
	 * 
	 * @author Manjunath Jakkandi
	 * @param model
	 *            EnrollRequestModel
	 * @return EnrollMemberResponse
	 */
	public EnrollMemberResponse enrollRequest(PBEnrollRequestModel model) throws Exception {
		log.info("enrollRequest");
		EnrollMemberResponse response = null;
		EnrollMemberRequest request = new EnrollMemberRequest();
		// Enrollment Details
		EnrolmentDetailsType details = new EnrolmentDetailsType();
		details.setPromotionalId(config.getDataSource().getPromotionalId());
		details.setSourcedAssociationId(config.getDataSource().getSourceAssociationId());
		details.setPhysicalCardTypeId(config.getDataSource().getPhysicalCardTypeId());
		details.setMemberCardTypeId(config.getDataSource().getMemberCardTypeId());
		details.setMemberClassId(config.getDataSource().getMemberClassId());
		request.setEnrolmentDetails(details);

		// Address
		MemberPostalAddressType address = new MemberPostalAddressType();
		address.setAdditionalAddress1(model.getAddress().getAddress1());
		address.setAdditionalAddress2(model.getAddress().getAddress2());
		address.setCity(model.getAddress().getCity());
		address.setRegion(model.getAddress().getRegion());
		address.setZipCode(model.getAddress().getZipCode());
		request.setPostalAddress(address);

		// Contact Details
		EnrollMemberContactType contact = new EnrollMemberContactType();
		contact.setLinkMobile("YES");
		EmailAddressType type1 = new EmailAddressType();
		type1.setAddress(model.getMasterinfo().getEmailId());
		contact.setEmailAddress(type1);
		PhoneNumberType type2 = new PhoneNumberType();
		type2.setNumber(model.getMasterinfo().getMobileNumber());
		contact.setMobileNumber(type2);
		request.setContactInfo(contact);

		// Master Info
		MemberMasterInfoType masterInfo = new MemberMasterInfoType();
		masterInfo.setSalutation(model.getMasterinfo().getSalutation());
		masterInfo.setFirstName(model.getMasterinfo().getFirstName());
		masterInfo.setLastName(model.getMasterinfo().getLastName());
		XMLGregorianCalendar xgcal = DatatypeFactory.newInstance()
				.newXMLGregorianCalendar(model.getMasterinfo().getDateOfBirth());
		masterInfo.setDateOfBirth(xgcal);
		request.setMasterInfo(masterInfo);
		request.setCommunicationChannel(config.getDataSource().getCommunicationChannel());

		response = (EnrollMemberResponse) getWebServiceTemplate().marshalSendAndReceive(request);
		return response;
	}

	/**
	 * This method used to consume payback API to get card details for given mobile
	 * number.
	 * 
	 * @author Manjunath Jakkandi
	 * @param mobileNumber
	 *            Mobile number.
	 * @return GetMemberCardDetailsByMobileResponse
	 */
	public GetMemberCardDetailsByMobileResponse getCardDetailsByMobileNumber(String mobileNumber) throws Exception {
		log.info("getCardDetailsByMobileNumber");
		GetMemberCardDetailsByMobileResponse response = null;
		GetMemberCardDetailsByMobileRequest request = new GetMemberCardDetailsByMobileRequest();
		request.setMobileNumber(mobileNumber);
		response = (GetMemberCardDetailsByMobileResponse) getWebServiceTemplate().marshalSendAndReceive(request);
		return response;
	}

	/**
	 * This method used to consume payback API to get card details for given email
	 * id.
	 * 
	 * @author Manjunath Jakkandi
	 * @param emailId
	 * @return
	 */
	public GetMemberCardsByEmailIdResponse getCardDetailsByEmailId(String emailId) throws Exception {
		log.info("getCardDetailsByEmailId");
		GetMemberCardsByEmailIdResponse response = null;
		GetMemberCardsByEmailIdRequest request = new GetMemberCardsByEmailIdRequest();
		request.setEmail(emailId);
		request.setPartnerShortName(config.getDataSource().getPartnerShortName());
		response = (GetMemberCardsByEmailIdResponse) getWebServiceTemplate().marshalSendAndReceive(request);
		return response;
	}

}
